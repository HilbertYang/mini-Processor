VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex2p"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL firstword
        SIGNAL lastword
        SIGNAL XLXN_4
        SIGNAL XLXN_5
        SIGNAL fifowrite
        SIGNAL tail_addr(7:0)
        SIGNAL rst
        SIGNAL waddr(7:0)
        SIGNAL fiforead
        SIGNAL finish
        SIGNAL in_fifo(71:0)
        SIGNAL XLXN_23
        SIGNAL valid_data
        SIGNAL raddr(7:0)
        SIGNAL in_fifo0(71:0)
        SIGNAL out_fifo(71:0)
        SIGNAL CLK
        SIGNAL CPU_ctrl
        SIGNAL head_addr(7:0)
        SIGNAL CPU_MEM_WRITE
        SIGNAL CPU_MEM_DATA(71:0)
        SIGNAL CPU_MEM_ADDR(7:0)
        SIGNAL XLXN_54(7:0)
        SIGNAL XLXN_56
        SIGNAL XLXN_63
        SIGNAL XLXN_67
        SIGNAL XLXN_73
        SIGNAL XLXN_76
        SIGNAL XLXN_77
        SIGNAL XLXN_80
        SIGNAL XLXN_81
        PORT Input firstword
        PORT Input lastword
        PORT Input fifowrite
        PORT Output tail_addr(7:0)
        PORT Input rst
        PORT Input fiforead
        PORT Output finish
        PORT Input in_fifo(71:0)
        PORT Output valid_data
        PORT Output out_fifo(71:0)
        PORT Input CLK
        PORT Input CPU_ctrl
        PORT Input head_addr(7:0)
        PORT Input CPU_MEM_WRITE
        PORT Input CPU_MEM_DATA(71:0)
        PORT Input CPU_MEM_ADDR(7:0)
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCKDEF fd8ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8cle
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -448 320 -64 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 0 -384 64 -384 
            RECTANGLE N 0 -396 64 -372 
            LINE N 384 -384 320 -384 
            LINE N 384 -192 320 -192 
            RECTANGLE N 320 -396 384 -372 
            LINE N 384 -128 320 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF comp8
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -384 320 -64 
            LINE N 384 -224 320 -224 
            RECTANGLE N 0 -332 64 -308 
            LINE N 0 -320 64 -320 
            RECTANGLE N 0 -140 64 -116 
            LINE N 0 -128 64 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF and3b2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
            LINE N 0 -128 40 -128 
            CIRCLE N 40 -140 64 -116 
            LINE N 0 -192 64 -192 
            LINE N 256 -128 192 -128 
            LINE N 64 -64 64 -192 
            ARC N 96 -176 192 -80 144 -80 144 -176 
            LINE N 144 -80 64 -80 
            LINE N 64 -176 144 -176 
        END BLOCKDEF
        BEGIN BLOCKDEF vcc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -32 64 -64 
            LINE N 64 0 64 -32 
            LINE N 96 -64 32 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF fdc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            RECTANGLE N 64 -320 320 -64 
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
            LINE N 192 -64 192 -32 
            LINE N 192 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF m2_1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 96 -64 96 -192 
            LINE N 256 -96 96 -64 
            LINE N 256 -160 256 -96 
            LINE N 96 -192 256 -160 
            LINE N 176 -32 96 -32 
            LINE N 176 -80 176 -32 
            LINE N 0 -32 96 -32 
            LINE N 320 -128 256 -128 
            LINE N 0 -96 96 -96 
            LINE N 0 -160 96 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF gnd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -64 64 -96 
            LINE N 76 -48 52 -48 
            LINE N 68 -32 60 -32 
            LINE N 88 -64 40 -64 
            LINE N 64 -64 64 -80 
            LINE N 64 -128 64 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF and2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF reg9B
            TIMESTAMP 2026 3 8 12 3 57
            RECTANGLE N 64 -256 320 0 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -236 384 -212 
            LINE N 320 -224 384 -224 
        END BLOCKDEF
        BEGIN BLOCKDEF SMem
            TIMESTAMP 2026 3 8 12 3 44
            RECTANGLE N 32 0 256 496 
            BEGIN LINE W 0 48 32 48 
            END LINE
            BEGIN LINE W 0 80 32 80 
            END LINE
            LINE N 0 112 32 112 
            LINE N 0 240 32 240 
            BEGIN LINE W 0 272 32 272 
            END LINE
            BEGIN LINE W 0 304 32 304 
            END LINE
            LINE N 0 336 32 336 
            LINE N 0 464 32 464 
            BEGIN LINE W 256 48 288 48 
            END LINE
            BEGIN LINE W 256 272 288 272 
            END LINE
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fd
            PIN C CLK
            PIN D firstword
            PIN Q XLXN_4
        END BLOCK
        BEGIN BLOCK XLXI_2 fd
            PIN C CLK
            PIN D lastword
            PIN Q XLXN_5
        END BLOCK
        BEGIN BLOCK XLXI_4 or2
            PIN I0 XLXN_5
            PIN I1 XLXN_4
            PIN O XLXN_80
        END BLOCK
        BEGIN BLOCK XLXI_6 fd
            PIN C CLK
            PIN D fifowrite
            PIN Q XLXN_56
        END BLOCK
        BEGIN BLOCK tailer_reg fd8ce
            PIN C CLK
            PIN CE XLXN_77
            PIN CLR rst
            PIN D(7:0) waddr(7:0)
            PIN Q(7:0) tail_addr(7:0)
        END BLOCK
        BEGIN BLOCK store_counter cb8cle
            PIN C CLK
            PIN CE XLXN_56
            PIN CLR rst
            PIN D(7:0) head_addr(7:0)
            PIN L CPU_ctrl
            PIN CEO
            PIN Q(7:0) waddr(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_10 comp8
            PIN A(7:0) raddr(7:0)
            PIN B(7:0) tail_addr(7:0)
            PIN EQ finish
        END BLOCK
        BEGIN BLOCK XLXI_11 and3b2
            PIN I0 finish
            PIN I1 CPU_ctrl
            PIN I2 fiforead
            PIN O XLXN_81
        END BLOCK
        BEGIN BLOCK XLXI_13 vcc
            PIN P XLXN_23
        END BLOCK
        BEGIN BLOCK XLXI_14 fdc
            PIN C CLK
            PIN CLR rst
            PIN D fiforead
            PIN Q valid_data
        END BLOCK
        BEGIN BLOCK sendout_counter cb8cle
            PIN C CLK
            PIN CE XLXN_81
            PIN CLR rst
            PIN D(7:0) head_addr(7:0)
            PIN L finish
            PIN CEO
            PIN Q(7:0) raddr(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_21(7:0) m2_1
            PIN D0 raddr(7:0)
            PIN D1 CPU_MEM_ADDR(7:0)
            PIN S0 CPU_ctrl
            PIN O XLXN_54(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_24 m2_1
            PIN D0 XLXN_63
            PIN D1 CPU_MEM_WRITE
            PIN S0 CPU_ctrl
            PIN O XLXN_67
        END BLOCK
        BEGIN BLOCK XLXI_25 gnd
            PIN G XLXN_63
        END BLOCK
        BEGIN BLOCK XLXI_28 fd
            PIN C CLK
            PIN D XLXN_80
            PIN Q XLXN_73
        END BLOCK
        BEGIN BLOCK XLXI_29 inv
            PIN I XLXN_73
            PIN O XLXN_76
        END BLOCK
        BEGIN BLOCK XLXI_30 and2
            PIN I0 XLXN_76
            PIN I1 XLXN_80
            PIN O XLXN_77
        END BLOCK
        BEGIN BLOCK XLXI_31 reg9B
            PIN d(71:0) in_fifo(71:0)
            PIN CLK CLK
            PIN CLR rst
            PIN CE XLXN_23
            PIN q(71:0) in_fifo0(71:0)
        END BLOCK
        BEGIN BLOCK XLXI_32 SMem
            PIN addra(7:0) waddr(7:0)
            PIN dina(71:0) in_fifo0(71:0)
            PIN wea XLXN_56
            PIN clka CLK
            PIN addrb(7:0) XLXN_54(7:0)
            PIN dinb(71:0) CPU_MEM_DATA(71:0)
            PIN web XLXN_67
            PIN clkb CLK
            PIN douta(71:0)
            PIN doutb(71:0) out_fifo(71:0)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 512 704 R0
        INSTANCE XLXI_2 512 1104 R0
        BEGIN BRANCH firstword
            WIRE 448 448 512 448
        END BRANCH
        BEGIN BRANCH lastword
            WIRE 432 848 512 848
        END BRANCH
        BEGIN BRANCH XLXN_4
            WIRE 896 448 928 448
            WIRE 928 448 928 560
            WIRE 928 560 960 560
        END BRANCH
        BEGIN BRANCH XLXN_5
            WIRE 896 848 912 848
            WIRE 912 736 912 848
            WIRE 912 736 944 736
            WIRE 944 624 944 736
            WIRE 944 624 960 624
        END BRANCH
        INSTANCE XLXI_6 1328 640 R0
        BEGIN BRANCH fifowrite
            WIRE 1296 384 1328 384
        END BRANCH
        BEGIN INSTANCE store_counter 1856 1264 R0
            BEGIN DISPLAY 0 -532 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        INSTANCE XLXI_10 1232 2240 R0
        BEGIN BRANCH fiforead
            WIRE 1488 2288 1744 2288
            WIRE 1744 2288 1952 2288
            WIRE 1744 1776 1744 2288
            WIRE 1744 1776 1904 1776
            WIRE 1952 2176 1952 2288
            WIRE 1952 2176 2176 2176
        END BRANCH
        INSTANCE XLXI_11 1904 1968 R0
        BEGIN BRANCH finish
            WIRE 1616 2016 1632 2016
            WIRE 1632 2016 1760 2016
            WIRE 1760 2016 2208 2016
            WIRE 1632 2016 1632 2512
            WIRE 1760 1904 1760 2016
            WIRE 1760 1904 1904 1904
            WIRE 2208 1776 2208 2016
            WIRE 2208 1776 2240 1776
        END BRANCH
        BEGIN BRANCH in_fifo(71:0)
            WIRE 1984 400 2064 400
        END BRANCH
        INSTANCE XLXI_13 1824 704 R0
        BEGIN BRANCH XLXN_23
            WIRE 1888 704 1888 768
            WIRE 1888 768 2016 768
            WIRE 2016 592 2064 592
            WIRE 2016 592 2016 768
        END BRANCH
        INSTANCE XLXI_14 2176 2432 R0
        BEGIN BRANCH valid_data
            WIRE 2560 2176 2592 2176
        END BRANCH
        BEGIN BRANCH out_fifo(71:0)
            WIRE 3232 1344 3472 1344
            WIRE 3472 1344 3472 1376
            WIRE 3472 1376 3504 1376
            WIRE 3504 1376 3504 1776
            WIRE 3344 1776 3344 1856
            WIRE 3344 1856 3360 1856
            WIRE 3344 1776 3504 1776
        END BRANCH
        IOMARKER 448 448 firstword R180 28
        IOMARKER 432 848 lastword R180 28
        IOMARKER 1296 384 fifowrite R180 28
        IOMARKER 1696 1232 rst R180 28
        IOMARKER 1488 2288 fiforead R180 28
        IOMARKER 1984 400 in_fifo(71:0) R180 28
        IOMARKER 2592 2176 valid_data R0 28
        IOMARKER 416 2128 CLK R180 28
        IOMARKER 608 1696 CPU_ctrl R180 28
        BEGIN BRANCH tail_addr(7:0)
            WIRE 912 1328 1216 1328
            WIRE 1216 1328 1216 1552
            WIRE 1216 1552 1216 2112
            WIRE 1216 2112 1232 2112
            WIRE 1216 1328 1344 1328
            BEGIN DISPLAY 1216 1552 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE tailer_reg 528 1584 R0
            BEGIN DISPLAY 0 -404 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH rst
            WIRE 528 1552 528 1568
            WIRE 528 1568 720 1568
            WIRE 720 1568 720 1616
            WIRE 720 1616 976 1616
            WIRE 976 1456 1728 1456
            WIRE 1728 1456 1728 2000
            WIRE 1728 2000 2240 2000
            WIRE 1728 2000 1728 2400
            WIRE 1728 2400 2176 2400
            WIRE 976 1456 976 1616
            WIRE 1696 1232 1728 1232
            WIRE 1728 1232 1856 1232
            WIRE 1728 1232 1728 1456
            WIRE 1728 528 2064 528
            WIRE 1728 528 1728 1232
        END BRANCH
        BEGIN BRANCH waddr(7:0)
            WIRE 464 1264 464 1328
            WIRE 464 1328 528 1328
            WIRE 464 1264 2320 1264
            WIRE 2240 880 2288 880
            WIRE 2288 880 2320 880
            WIRE 2320 880 2320 1264
            WIRE 2320 880 2608 880
            WIRE 2608 880 2608 1120
            WIRE 2608 1120 2944 1120
            BEGIN DISPLAY 2288 880 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE sendout_counter 2240 2032 R0
            BEGIN DISPLAY 0 -532 ATTR InstName
                FONT 28 "Arial"
            END DISPLAY
        END INSTANCE
        BEGIN BRANCH head_addr(7:0)
            WIRE 1536 736 1536 800
            WIRE 1536 736 1616 736
            WIRE 1616 736 1616 880
            WIRE 1616 880 1856 880
            WIRE 1616 880 1616 1648
            WIRE 1616 1648 2240 1648
        END BRANCH
        IOMARKER 3360 1856 out_fifo(71:0) R0 28
        BEGIN BRANCH CLK
            WIRE 416 2128 432 2128
            WIRE 432 2128 448 2128
            WIRE 432 2128 432 2256
            WIRE 432 2256 1552 2256
            WIRE 1552 2256 1552 2304
            WIRE 1552 2304 1856 2304
            WIRE 1856 2304 2016 2304
            WIRE 2016 2304 2176 2304
            WIRE 432 976 432 1296
            WIRE 432 1296 432 2128
            WIRE 432 1296 448 1296
            WIRE 448 1296 448 1456
            WIRE 448 1456 528 1456
            WIRE 432 976 448 976
            WIRE 448 976 512 976
            WIRE 448 976 448 1120
            WIRE 448 1120 1024 1120
            WIRE 448 576 512 576
            WIRE 448 576 448 720
            WIRE 448 720 448 976
            WIRE 448 720 912 720
            WIRE 912 512 912 720
            WIRE 912 512 1328 512
            WIRE 1792 464 2064 464
            WIRE 1792 464 1792 1136
            WIRE 1792 1136 1856 1136
            WIRE 1792 1136 1792 1312
            WIRE 1792 1312 1856 1312
            WIRE 1856 1312 1856 2304
            WIRE 1856 1312 2672 1312
            WIRE 2672 1312 2672 1568
            WIRE 2672 1568 2896 1568
            WIRE 2672 1312 2944 1312
            WIRE 2016 2048 2016 2304
            WIRE 2016 2048 2224 2048
            WIRE 2224 1904 2224 2048
            WIRE 2224 1904 2240 1904
            WIRE 2896 1536 2944 1536
            WIRE 2896 1536 2896 1568
        END BRANCH
        BEGIN BRANCH in_fifo0(71:0)
            WIRE 2448 400 2560 400
            WIRE 2560 400 2560 1152
            WIRE 2560 1152 2944 1152
            BEGIN DISPLAY 2560 400 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CPU_MEM_DATA(71:0)
            WIRE 2928 1376 2944 1376
            WIRE 2928 1376 2928 1648
            WIRE 2928 1648 3328 1648
            WIRE 3328 1648 3328 2336
        END BRANCH
        INSTANCE XLXI_21(7:0) 2752 1936 R0
        BEGIN BRANCH raddr(7:0)
            WIRE 1168 1408 1168 1920
            WIRE 1168 1920 1232 1920
            WIRE 1168 1408 2688 1408
            WIRE 2688 1408 2688 1648
            WIRE 2688 1648 2688 1776
            WIRE 2688 1776 2752 1776
            WIRE 2624 1648 2672 1648
            WIRE 2672 1648 2688 1648
            BEGIN DISPLAY 2672 1648 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH CPU_MEM_ADDR(7:0)
            WIRE 2736 1840 2752 1840
            WIRE 2736 1840 2736 2080
            WIRE 2736 2080 3248 2080
            WIRE 3248 2080 3248 2176
        END BRANCH
        BEGIN BRANCH XLXN_54(7:0)
            WIRE 2848 1376 2896 1376
            WIRE 2848 1376 2848 1696
            WIRE 2848 1696 3136 1696
            WIRE 3136 1696 3136 1808
            WIRE 2896 1344 2944 1344
            WIRE 2896 1344 2896 1376
            WIRE 3072 1808 3136 1808
        END BRANCH
        IOMARKER 1632 2512 finish R90 28
        IOMARKER 1344 1328 tail_addr(7:0) R0 28
        IOMARKER 1536 800 head_addr(7:0) R90 28
        BEGIN BRANCH XLXN_56
            WIRE 1712 384 1760 384
            WIRE 1760 384 1760 1072
            WIRE 1760 1072 1856 1072
            WIRE 1760 1072 1760 1248
            WIRE 1760 1248 2896 1248
            WIRE 2896 1184 2944 1184
            WIRE 2896 1184 2896 1248
        END BRANCH
        BEGIN BRANCH CPU_MEM_WRITE
            WIRE 2704 2272 2720 2272
            WIRE 2704 2272 2704 2400
            WIRE 2704 2400 2848 2400
            WIRE 2848 2400 2848 2416
        END BRANCH
        INSTANCE XLXI_25 2464 2656 R0
        IOMARKER 2848 2416 CPU_MEM_WRITE R90 28
        BEGIN BRANCH XLXN_63
            WIRE 2528 2512 2528 2528
            WIRE 2528 2512 2624 2512
            WIRE 2624 2208 2624 2512
            WIRE 2624 2208 2720 2208
        END BRANCH
        INSTANCE XLXI_24 2720 2368 R0
        IOMARKER 3328 2336 CPU_MEM_DATA(71:0) R90 28
        IOMARKER 3248 2176 CPU_MEM_ADDR(7:0) R90 28
        BEGIN BRANCH XLXN_67
            WIRE 2864 1408 2944 1408
            WIRE 2864 1408 2864 1632
            WIRE 2864 1632 3088 1632
            WIRE 3088 1632 3088 2240
            WIRE 3040 2240 3088 2240
        END BRANCH
        BEGIN BRANCH CPU_ctrl
            WIRE 608 1696 1056 1696
            WIRE 1056 1696 1760 1696
            WIRE 1760 1696 1760 1840
            WIRE 1760 1840 1904 1840
            WIRE 1760 1696 1840 1696
            WIRE 1840 1696 1840 2064
            WIRE 1840 2064 2752 2064
            WIRE 1056 1280 1056 1696
            WIRE 1056 1280 1856 1280
            WIRE 1856 1008 1856 1280
            WIRE 2576 2048 2576 2336
            WIRE 2576 2336 2720 2336
            WIRE 2576 2048 2752 2048
            WIRE 2752 2048 2752 2064
            WIRE 2752 1904 2752 2048
        END BRANCH
        INSTANCE XLXI_28 1024 1248 R0
        INSTANCE XLXI_30 1232 784 R0
        BEGIN BRANCH XLXN_76
            WIRE 1152 720 1216 720
            WIRE 1216 720 1232 720
            WIRE 1152 720 1152 784
            WIRE 1152 784 1424 784
            WIRE 1424 784 1424 832
            WIRE 1408 832 1424 832
        END BRANCH
        BEGIN BRANCH XLXN_77
            WIRE 512 1200 512 1392
            WIRE 512 1392 528 1392
            WIRE 512 1200 944 1200
            WIRE 944 752 1552 752
            WIRE 944 752 944 992
            WIRE 944 992 944 1200
            WIRE 1488 688 1552 688
            WIRE 1552 688 1552 752
        END BRANCH
        BEGIN BRANCH XLXN_73
            WIRE 1120 832 1120 880
            WIRE 1120 880 1424 880
            WIRE 1424 880 1424 992
            WIRE 1120 832 1184 832
            WIRE 1408 992 1424 992
        END BRANCH
        INSTANCE XLXI_29 1184 864 R0
        INSTANCE XLXI_4 960 688 R0
        BEGIN BRANCH XLXN_80
            WIRE 496 288 1312 288
            WIRE 1312 288 1312 592
            WIRE 496 288 496 656
            WIRE 496 656 1232 656
            WIRE 960 992 1024 992
            WIRE 960 992 960 1200
            WIRE 960 1200 1712 1200
            WIRE 1216 592 1248 592
            WIRE 1248 592 1312 592
            WIRE 1248 592 1248 608
            WIRE 1248 608 1712 608
            WIRE 1712 608 1712 1200
        END BRANCH
        BEGIN INSTANCE XLXI_31 2064 624 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_32 2944 1072 R0
        END INSTANCE
        BEGIN BRANCH XLXN_81
            WIRE 2160 1840 2240 1840
        END BRANCH
    END SHEET
END SCHEMATIC
