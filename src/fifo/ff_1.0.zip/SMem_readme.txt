The following files were generated for 'SMem' in directory 
C:\f8\f2:

SMem.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

SMem.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

SMem.sym:
   Please see the core data sheet.

SMem.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

SMem.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

SMem.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

SMem.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

SMem.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

SMem_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

SMem_readme.txt:
   Text file indicating the files generated and how they are used.

SMem_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

