VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex2p"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL d(71:0)
        SIGNAL q(71:0)
        SIGNAL d(15:0)
        SIGNAL d(31:16)
        SIGNAL d(47:32)
        SIGNAL d(63:48)
        SIGNAL d(71:64)
        SIGNAL q(71:64)
        SIGNAL q(63:48)
        SIGNAL q(47:32)
        SIGNAL q(31:16)
        SIGNAL q(15:0)
        SIGNAL CLK
        SIGNAL CLR
        SIGNAL CE
        PORT Input d(71:0)
        PORT Output q(71:0)
        PORT Input CLK
        PORT Input CLR
        PORT Input CE
        BEGIN BLOCKDEF fd16ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF fd8ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_2 fd16ce
            PIN C CLK
            PIN CE CE
            PIN CLR CLR
            PIN D(15:0) d(63:48)
            PIN Q(15:0) q(63:48)
        END BLOCK
        BEGIN BLOCK XLXI_3 fd16ce
            PIN C CLK
            PIN CE CE
            PIN CLR CLR
            PIN D(15:0) d(47:32)
            PIN Q(15:0) q(47:32)
        END BLOCK
        BEGIN BLOCK XLXI_4 fd16ce
            PIN C CLK
            PIN CE CE
            PIN CLR CLR
            PIN D(15:0) d(31:16)
            PIN Q(15:0) q(31:16)
        END BLOCK
        BEGIN BLOCK XLXI_5 fd16ce
            PIN C CLK
            PIN CE CE
            PIN CLR CLR
            PIN D(15:0) d(15:0)
            PIN Q(15:0) q(15:0)
        END BLOCK
        BEGIN BLOCK XLXI_6 fd8ce
            PIN C CLK
            PIN CE CE
            PIN CLR CLR
            PIN D(7:0) d(71:64)
            PIN Q(7:0) q(71:64)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN BRANCH d(71:0)
            WIRE 208 48 272 48
        END BRANCH
        BEGIN BRANCH q(71:0)
            WIRE 208 112 272 112
        END BRANCH
        IOMARKER 208 48 d(71:0) R180 28
        IOMARKER 208 112 q(71:0) R180 28
        INSTANCE XLXI_2 496 880 R0
        INSTANCE XLXI_3 496 1232 R0
        INSTANCE XLXI_4 496 1664 R0
        INSTANCE XLXI_5 512 2160 R0
        BEGIN BRANCH d(15:0)
            WIRE 496 1904 512 1904
            BEGIN DISPLAY 496 1904 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(31:16)
            WIRE 480 1408 496 1408
            BEGIN DISPLAY 480 1408 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(47:32)
            WIRE 480 976 496 976
            BEGIN DISPLAY 480 976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(63:48)
            WIRE 464 624 496 624
            BEGIN DISPLAY 464 624 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(71:64)
            WIRE 464 240 496 240
            BEGIN DISPLAY 464 240 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(71:64)
            WIRE 880 240 912 240
            BEGIN DISPLAY 912 240 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(63:48)
            WIRE 880 624 912 624
            BEGIN DISPLAY 912 624 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(47:32)
            WIRE 880 976 912 976
            BEGIN DISPLAY 912 976 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(31:16)
            WIRE 880 1408 928 1408
            BEGIN DISPLAY 928 1408 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(15:0)
            WIRE 896 1904 912 1904
            BEGIN DISPLAY 912 1904 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_6 496 496 R0
        IOMARKER 128 1088 CE R180 28
        IOMARKER 128 1136 CLK R180 28
        BEGIN BRANCH CLK
            WIRE 128 1136 208 1136
            WIRE 208 1136 208 1536
            WIRE 208 1536 496 1536
            WIRE 208 1536 208 2032
            WIRE 208 2032 512 2032
            WIRE 208 368 496 368
            WIRE 208 368 208 752
            WIRE 208 752 496 752
            WIRE 208 752 208 1104
            WIRE 208 1104 208 1136
            WIRE 208 1104 496 1104
        END BRANCH
        IOMARKER 160 1296 CLR R180 28
        BEGIN BRANCH CLR
            WIRE 160 1296 304 1296
            WIRE 304 1296 304 1632
            WIRE 304 1632 496 1632
            WIRE 304 1632 304 2128
            WIRE 304 2128 512 2128
            WIRE 304 464 496 464
            WIRE 304 464 304 848
            WIRE 304 848 304 1200
            WIRE 304 1200 304 1296
            WIRE 304 1200 496 1200
            WIRE 304 848 496 848
        END BRANCH
        BEGIN BRANCH CE
            WIRE 128 1088 224 1088
            WIRE 224 1088 224 1472
            WIRE 224 1472 496 1472
            WIRE 224 1472 224 1968
            WIRE 224 1968 512 1968
            WIRE 224 304 496 304
            WIRE 224 304 224 688
            WIRE 224 688 496 688
            WIRE 224 688 224 1040
            WIRE 224 1040 224 1088
            WIRE 224 1040 496 1040
        END BRANCH
    END SHEET
END SCHEMATIC
