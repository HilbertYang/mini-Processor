/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/f8/f2/fifo.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {1U, 0U};
static int ng5[] = {3, 0};
static unsigned int ng6[] = {2U, 0U};
static unsigned int ng7[] = {3U, 0U};
static unsigned int ng8[] = {4U, 0U};
static int ng9[] = {0, 0, 0, 0};



static void C122_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;

LAB0:    t1 = (t0 + 5548U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2932U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4U);
    t5 = (t4 + 4U);
    t6 = *((unsigned int *)t5);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t5) == 0)
        goto LAB4;

LAB6:    *((unsigned int *)t3) = 1;
    *((unsigned int *)t2) = 1;

LAB7:    t11 = (t0 + 6452);
    t12 = (t11 + 32U);
    t13 = *((char **)t12);
    t14 = (t13 + 40U);
    t15 = *((char **)t14);
    t16 = (t15 + 4U);
    t17 = 1U;
    t18 = t17;
    t19 = (t3 + 4U);
    t20 = *((unsigned int *)t3);
    t17 = (t17 & t20);
    t21 = *((unsigned int *)t19);
    t18 = (t18 & t21);
    t22 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t22 & 4294967294U);
    t23 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t23 | t17);
    t24 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t24 & 4294967294U);
    t25 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t25 | t18);
    xsi_driver_vfirst_trans(t11, 0, 0);
    t26 = (t0 + 6368);
    *((int *)t26) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t3) = 1;
    goto LAB7;

}

static void C123_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;

LAB0:    t1 = (t0 + 5676U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4336);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 6488);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    t10 = (t9 + 4U);
    t11 = 1U;
    t12 = t11;
    t13 = (t4 + 4U);
    t14 = *((unsigned int *)t4);
    t11 = (t11 & t14);
    t15 = *((unsigned int *)t13);
    t12 = (t12 & t15);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 | t11);
    t18 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t18 & 4294967294U);
    t19 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t19 | t12);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t20 = (t0 + 6376);
    *((int *)t20) = 1;

LAB1:    return;
}

static void A234_2(char *t0)
{
    char t7[8];
    char t13[8];
    char t25[8];
    char t32[8];
    char t88[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;
    char *t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    int t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    int t77;
    unsigned int t78;
    unsigned int t79;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    char *t86;
    char *t87;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;

LAB0:    t1 = (t0 + 5804U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(234, ng0);
    t2 = (t0 + 6384);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(234, ng0);

LAB5:    xsi_set_current_line(235, ng0);
    t3 = (t0 + 3968);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 4060);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 3);
    xsi_set_current_line(237, ng0);
    t2 = (t0 + 4704);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 4796);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 3);
    xsi_set_current_line(238, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3692);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(239, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 5072);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(240, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3876);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(242, ng0);
    t2 = (t0 + 4336);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 4428);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(243, ng0);
    t2 = (t0 + 4152);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 4244);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(244, ng0);
    t2 = (t0 + 4520);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 4612);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(245, ng0);
    t2 = (t0 + 4888);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 4980);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(258, ng0);
    t2 = (t0 + 3020U);
    t3 = *((char **)t2);
    memset(t7, 0, 8);
    t2 = (t7 + 4U);
    t4 = (t3 + 4U);
    t8 = *((unsigned int *)t4);
    t9 = (~(t8));
    t10 = *((unsigned int *)t3);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t4) == 0)
        goto LAB6;

LAB8:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t2) = 1;

LAB9:    memset(t13, 0, 8);
    t5 = (t13 + 4U);
    t6 = (t7 + 4U);
    t14 = *((unsigned int *)t6);
    t15 = (~(t14));
    t16 = *((unsigned int *)t7);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t6) != 0)
        goto LAB12;

LAB13:    t19 = (t13 + 4U);
    t20 = *((unsigned int *)t13);
    t21 = *((unsigned int *)t19);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB14;

LAB15:    memcpy(t32, t13, 8);

LAB16:    t64 = (t32 + 4U);
    t65 = *((unsigned int *)t64);
    t66 = (~(t65));
    t67 = *((unsigned int *)t32);
    t68 = (t67 & t66);
    t69 = (t68 != 0);
    if (t69 > 0)
        goto LAB24;

LAB25:
LAB26:    xsi_set_current_line(263, ng0);
    t2 = (t0 + 4888);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 4U);
    t8 = *((unsigned int *)t5);
    t9 = (~(t8));
    t10 = *((unsigned int *)t4);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB28;

LAB29:
LAB30:    xsi_set_current_line(268, ng0);
    t2 = (t0 + 3968);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);

LAB32:    t5 = ((char*)((ng3)));
    t56 = xsi_vlog_unsigned_case_compare(t4, 3, t5, 3);
    if (t56 == 1)
        goto LAB33;

LAB34:    t2 = ((char*)((ng4)));
    t56 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t56 == 1)
        goto LAB35;

LAB36:    t2 = ((char*)((ng6)));
    t56 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t56 == 1)
        goto LAB37;

LAB38:    t2 = ((char*)((ng7)));
    t56 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t56 == 1)
        goto LAB39;

LAB40:    t2 = ((char*)((ng8)));
    t56 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t56 == 1)
        goto LAB41;

LAB42:
LAB43:    goto LAB2;

LAB6:    *((unsigned int *)t7) = 1;
    goto LAB9;

LAB10:    *((unsigned int *)t13) = 1;
    goto LAB13;

LAB12:    *((unsigned int *)t13) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB13;

LAB14:    t23 = (t0 + 1788U);
    t24 = *((char **)t23);
    memset(t25, 0, 8);
    t23 = (t25 + 4U);
    t26 = (t24 + 4U);
    t27 = *((unsigned int *)t26);
    t28 = (~(t27));
    t29 = *((unsigned int *)t24);
    t30 = (t29 & t28);
    t31 = (t30 & 1U);
    if (t31 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t26) != 0)
        goto LAB19;

LAB20:    t33 = *((unsigned int *)t13);
    t34 = *((unsigned int *)t25);
    t35 = (t33 & t34);
    *((unsigned int *)t32) = t35;
    t36 = (t13 + 4U);
    t37 = (t25 + 4U);
    t38 = (t32 + 4U);
    t39 = *((unsigned int *)t36);
    t40 = *((unsigned int *)t37);
    t41 = (t39 | t40);
    *((unsigned int *)t38) = t41;
    t42 = *((unsigned int *)t38);
    t43 = (t42 != 0);
    if (t43 == 1)
        goto LAB21;

LAB22:
LAB23:    goto LAB16;

LAB17:    *((unsigned int *)t25) = 1;
    goto LAB20;

LAB19:    *((unsigned int *)t25) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB20;

LAB21:    t44 = *((unsigned int *)t32);
    t45 = *((unsigned int *)t38);
    *((unsigned int *)t32) = (t44 | t45);
    t46 = (t13 + 4U);
    t47 = (t25 + 4U);
    t48 = *((unsigned int *)t13);
    t49 = (~(t48));
    t50 = *((unsigned int *)t46);
    t51 = (~(t50));
    t52 = *((unsigned int *)t25);
    t53 = (~(t52));
    t54 = *((unsigned int *)t47);
    t55 = (~(t54));
    t56 = (t49 & t51);
    t57 = (t53 & t55);
    t58 = (~(t56));
    t59 = (~(t57));
    t60 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t60 & t58);
    t61 = *((unsigned int *)t38);
    *((unsigned int *)t38) = (t61 & t59);
    t62 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t62 & t58);
    t63 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t63 & t59);
    goto LAB23;

LAB24:    xsi_set_current_line(258, ng0);

LAB27:    xsi_set_current_line(259, ng0);
    t70 = ((char*)((ng2)));
    t71 = (t0 + 3876);
    xsi_vlogvar_assign_value(t71, t70, 0, 0, 1);
    xsi_set_current_line(260, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3692);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB26;

LAB28:    xsi_set_current_line(263, ng0);

LAB31:    xsi_set_current_line(264, ng0);
    t6 = ((char*)((ng1)));
    t19 = (t0 + 3692);
    xsi_vlogvar_assign_value(t19, t6, 0, 0, 1);
    xsi_set_current_line(265, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3876);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB30;

LAB33:    xsi_set_current_line(269, ng0);

LAB44:    xsi_set_current_line(270, ng0);
    t6 = (t0 + 2844U);
    t19 = *((char **)t6);
    t6 = ((char*)((ng1)));
    memset(t7, 0, 8);
    t23 = (t7 + 4U);
    t24 = (t19 + 4U);
    t26 = (t6 + 4U);
    t8 = *((unsigned int *)t19);
    t9 = *((unsigned int *)t6);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t24);
    t12 = *((unsigned int *)t26);
    t14 = (t11 ^ t12);
    t15 = (t10 | t14);
    t16 = *((unsigned int *)t24);
    t17 = *((unsigned int *)t26);
    t18 = (t16 | t17);
    t20 = (~(t18));
    t21 = (t15 & t20);
    if (t21 != 0)
        goto LAB46;

LAB45:    if (t18 != 0)
        goto LAB47;

LAB48:    memset(t13, 0, 8);
    t36 = (t13 + 4U);
    t37 = (t7 + 4U);
    t22 = *((unsigned int *)t37);
    t27 = (~(t22));
    t28 = *((unsigned int *)t7);
    t29 = (t28 & t27);
    t30 = (t29 & 1U);
    if (t30 != 0)
        goto LAB49;

LAB50:    if (*((unsigned int *)t37) != 0)
        goto LAB51;

LAB52:    t38 = (t13 + 4U);
    t31 = *((unsigned int *)t13);
    t33 = *((unsigned int *)t38);
    t34 = (t31 || t33);
    if (t34 > 0)
        goto LAB53;

LAB54:    memcpy(t32, t13, 8);

LAB55:    t80 = (t32 + 4U);
    t81 = *((unsigned int *)t80);
    t82 = (~(t81));
    t83 = *((unsigned int *)t32);
    t84 = (t83 & t82);
    t85 = (t84 != 0);
    if (t85 > 0)
        goto LAB63;

LAB64:
LAB65:    goto LAB43;

LAB35:    xsi_set_current_line(276, ng0);

LAB67:    xsi_set_current_line(277, ng0);
    t3 = ((char*)((ng1)));
    t5 = (t0 + 4612);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    xsi_set_current_line(278, ng0);
    t2 = (t0 + 2844U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t7, 0, 8);
    t5 = (t7 + 4U);
    t6 = (t3 + 4U);
    t19 = (t2 + 4U);
    t8 = *((unsigned int *)t3);
    t9 = *((unsigned int *)t2);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t19);
    t14 = (t11 ^ t12);
    t15 = (t10 | t14);
    t16 = *((unsigned int *)t6);
    t17 = *((unsigned int *)t19);
    t18 = (t16 | t17);
    t20 = (~(t18));
    t21 = (t15 & t20);
    if (t21 != 0)
        goto LAB71;

LAB68:    if (t18 != 0)
        goto LAB70;

LAB69:    *((unsigned int *)t7) = 1;

LAB71:    t23 = (t7 + 4U);
    t22 = *((unsigned int *)t23);
    t27 = (~(t22));
    t28 = *((unsigned int *)t7);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB72;

LAB73:
LAB74:    goto LAB43;

LAB37:    xsi_set_current_line(285, ng0);

LAB84:    xsi_set_current_line(286, ng0);
    t3 = (t0 + 2844U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng1)));
    memset(t7, 0, 8);
    t6 = (t7 + 4U);
    t19 = (t5 + 4U);
    t23 = (t3 + 4U);
    t8 = *((unsigned int *)t5);
    t9 = *((unsigned int *)t3);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t19);
    t12 = *((unsigned int *)t23);
    t14 = (t11 ^ t12);
    t15 = (t10 | t14);
    t16 = *((unsigned int *)t19);
    t17 = *((unsigned int *)t23);
    t18 = (t16 | t17);
    t20 = (~(t18));
    t21 = (t15 & t20);
    if (t21 != 0)
        goto LAB86;

LAB85:    if (t18 != 0)
        goto LAB87;

LAB88:    t24 = (t7 + 4U);
    t22 = *((unsigned int *)t24);
    t27 = (~(t22));
    t28 = *((unsigned int *)t7);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB89;

LAB90:    xsi_set_current_line(297, ng0);

LAB93:    xsi_set_current_line(298, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4244);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB91:    goto LAB43;

LAB39:    xsi_set_current_line(301, ng0);

LAB94:    xsi_set_current_line(302, ng0);
    t3 = ((char*)((ng1)));
    t5 = (t0 + 4428);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    xsi_set_current_line(303, ng0);
    t2 = (t0 + 2052U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t7, 0, 8);
    t5 = (t7 + 4U);
    t6 = (t3 + 4U);
    t19 = (t2 + 4U);
    t8 = *((unsigned int *)t3);
    t9 = *((unsigned int *)t2);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t19);
    t14 = (t11 ^ t12);
    t15 = (t10 | t14);
    t16 = *((unsigned int *)t6);
    t17 = *((unsigned int *)t19);
    t18 = (t16 | t17);
    t20 = (~(t18));
    t21 = (t15 & t20);
    if (t21 != 0)
        goto LAB98;

LAB95:    if (t18 != 0)
        goto LAB97;

LAB96:    *((unsigned int *)t7) = 1;

LAB98:    memset(t13, 0, 8);
    t23 = (t13 + 4U);
    t24 = (t7 + 4U);
    t22 = *((unsigned int *)t24);
    t27 = (~(t22));
    t28 = *((unsigned int *)t7);
    t29 = (t28 & t27);
    t30 = (t29 & 1U);
    if (t30 != 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t24) != 0)
        goto LAB101;

LAB102:    t26 = (t13 + 4U);
    t31 = *((unsigned int *)t13);
    t33 = *((unsigned int *)t26);
    t34 = (t31 || t33);
    if (t34 > 0)
        goto LAB103;

LAB104:    memcpy(t88, t13, 8);

LAB105:    t76 = (t88 + 4U);
    t96 = *((unsigned int *)t76);
    t97 = (~(t96));
    t98 = *((unsigned int *)t88);
    t99 = (t98 & t97);
    t100 = (t99 != 0);
    if (t100 > 0)
        goto LAB117;

LAB118:
LAB119:    goto LAB43;

LAB41:    xsi_set_current_line(307, ng0);

LAB121:    xsi_set_current_line(308, ng0);
    t3 = ((char*)((ng2)));
    t5 = (t0 + 5072);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    xsi_set_current_line(309, ng0);
    t2 = (t0 + 2580U);
    t3 = *((char **)t2);
    t2 = (t3 + 4U);
    t8 = *((unsigned int *)t2);
    t9 = (~(t8));
    t10 = *((unsigned int *)t3);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB122;

LAB123:
LAB124:    goto LAB43;

LAB46:    *((unsigned int *)t7) = 1;
    goto LAB48;

LAB47:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB48;

LAB49:    *((unsigned int *)t13) = 1;
    goto LAB52;

LAB51:    *((unsigned int *)t13) = 1;
    *((unsigned int *)t36) = 1;
    goto LAB52;

LAB53:    t46 = (t0 + 3692);
    t47 = (t46 + 32U);
    t64 = *((char **)t47);
    memset(t25, 0, 8);
    t70 = (t25 + 4U);
    t71 = (t64 + 4U);
    t35 = *((unsigned int *)t71);
    t39 = (~(t35));
    t40 = *((unsigned int *)t64);
    t41 = (t40 & t39);
    t42 = (t41 & 1U);
    if (t42 != 0)
        goto LAB56;

LAB57:    if (*((unsigned int *)t71) != 0)
        goto LAB58;

LAB59:    t43 = *((unsigned int *)t13);
    t44 = *((unsigned int *)t25);
    t45 = (t43 & t44);
    *((unsigned int *)t32) = t45;
    t72 = (t13 + 4U);
    t73 = (t25 + 4U);
    t74 = (t32 + 4U);
    t48 = *((unsigned int *)t72);
    t49 = *((unsigned int *)t73);
    t50 = (t48 | t49);
    *((unsigned int *)t74) = t50;
    t51 = *((unsigned int *)t74);
    t52 = (t51 != 0);
    if (t52 == 1)
        goto LAB60;

LAB61:
LAB62:    goto LAB55;

LAB56:    *((unsigned int *)t25) = 1;
    goto LAB59;

LAB58:    *((unsigned int *)t25) = 1;
    *((unsigned int *)t70) = 1;
    goto LAB59;

LAB60:    t53 = *((unsigned int *)t32);
    t54 = *((unsigned int *)t74);
    *((unsigned int *)t32) = (t53 | t54);
    t75 = (t13 + 4U);
    t76 = (t25 + 4U);
    t55 = *((unsigned int *)t13);
    t58 = (~(t55));
    t59 = *((unsigned int *)t75);
    t60 = (~(t59));
    t61 = *((unsigned int *)t25);
    t62 = (~(t61));
    t63 = *((unsigned int *)t76);
    t65 = (~(t63));
    t57 = (t58 & t60);
    t77 = (t62 & t65);
    t66 = (~(t57));
    t67 = (~(t77));
    t68 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t68 & t66);
    t69 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t69 & t67);
    t78 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t78 & t66);
    t79 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t79 & t67);
    goto LAB62;

LAB63:    xsi_set_current_line(270, ng0);

LAB66:    xsi_set_current_line(271, ng0);
    t86 = ((char*)((ng4)));
    t87 = (t0 + 4060);
    xsi_vlogvar_assign_value(t87, t86, 0, 0, 3);
    xsi_set_current_line(272, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4612);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(273, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4428);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB65;

LAB70:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB71;

LAB72:    xsi_set_current_line(278, ng0);

LAB75:    xsi_set_current_line(279, ng0);
    t24 = (t0 + 4704);
    t26 = (t24 + 32U);
    t36 = *((char **)t26);
    t37 = ((char*)((ng4)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_add(t13, 3, t36, 3, t37, 3);
    t38 = (t0 + 4796);
    xsi_vlogvar_assign_value(t38, t13, 0, 0, 3);
    xsi_set_current_line(280, ng0);
    t2 = (t0 + 4796);
    t3 = (t2 + 32U);
    t5 = *((char **)t3);
    t6 = ((char*)((ng5)));
    memset(t7, 0, 8);
    t19 = (t7 + 4U);
    t23 = (t5 + 4U);
    t24 = (t6 + 4U);
    t8 = *((unsigned int *)t5);
    t9 = *((unsigned int *)t6);
    t10 = (t8 ^ t9);
    t11 = *((unsigned int *)t23);
    t12 = *((unsigned int *)t24);
    t14 = (t11 ^ t12);
    t15 = (t10 | t14);
    t16 = *((unsigned int *)t23);
    t17 = *((unsigned int *)t24);
    t18 = (t16 | t17);
    t20 = (~(t18));
    t21 = (t15 & t20);
    if (t21 != 0)
        goto LAB79;

LAB76:    if (t18 != 0)
        goto LAB78;

LAB77:    *((unsigned int *)t7) = 1;

LAB79:    t26 = (t7 + 4U);
    t22 = *((unsigned int *)t26);
    t27 = (~(t22));
    t28 = *((unsigned int *)t7);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB80;

LAB81:
LAB82:    goto LAB74;

LAB78:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB79;

LAB80:    xsi_set_current_line(280, ng0);

LAB83:    xsi_set_current_line(281, ng0);
    t36 = ((char*)((ng6)));
    t37 = (t0 + 4060);
    xsi_vlogvar_assign_value(t37, t36, 0, 0, 3);
    goto LAB82;

LAB86:    *((unsigned int *)t7) = 1;
    goto LAB88;

LAB87:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB88;

LAB89:    xsi_set_current_line(286, ng0);

LAB92:    xsi_set_current_line(287, ng0);
    t26 = ((char*)((ng7)));
    t36 = (t0 + 4060);
    xsi_vlogvar_assign_value(t36, t26, 0, 0, 3);
    xsi_set_current_line(288, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4796);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 3);
    xsi_set_current_line(289, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4980);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(294, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4428);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(295, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4244);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB91;

LAB97:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB98;

LAB99:    *((unsigned int *)t13) = 1;
    goto LAB102;

LAB101:    *((unsigned int *)t13) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB102;

LAB103:    t36 = (t0 + 2668U);
    t37 = *((char **)t36);
    t36 = ((char*)((ng1)));
    memset(t25, 0, 8);
    t38 = (t25 + 4U);
    t46 = (t37 + 4U);
    t47 = (t36 + 4U);
    t35 = *((unsigned int *)t37);
    t39 = *((unsigned int *)t36);
    t40 = (t35 ^ t39);
    t41 = *((unsigned int *)t46);
    t42 = *((unsigned int *)t47);
    t43 = (t41 ^ t42);
    t44 = (t40 | t43);
    t45 = *((unsigned int *)t46);
    t48 = *((unsigned int *)t47);
    t49 = (t45 | t48);
    t50 = (~(t49));
    t51 = (t44 & t50);
    if (t51 != 0)
        goto LAB109;

LAB106:    if (t49 != 0)
        goto LAB108;

LAB107:    *((unsigned int *)t25) = 1;

LAB109:    memset(t32, 0, 8);
    t64 = (t32 + 4U);
    t70 = (t25 + 4U);
    t52 = *((unsigned int *)t70);
    t53 = (~(t52));
    t54 = *((unsigned int *)t25);
    t55 = (t54 & t53);
    t58 = (t55 & 1U);
    if (t58 != 0)
        goto LAB110;

LAB111:    if (*((unsigned int *)t70) != 0)
        goto LAB112;

LAB113:    t59 = *((unsigned int *)t13);
    t60 = *((unsigned int *)t32);
    t61 = (t59 & t60);
    *((unsigned int *)t88) = t61;
    t71 = (t13 + 4U);
    t72 = (t32 + 4U);
    t73 = (t88 + 4U);
    t62 = *((unsigned int *)t71);
    t63 = *((unsigned int *)t72);
    t65 = (t62 | t63);
    *((unsigned int *)t73) = t65;
    t66 = *((unsigned int *)t73);
    t67 = (t66 != 0);
    if (t67 == 1)
        goto LAB114;

LAB115:
LAB116:    goto LAB105;

LAB108:    *((unsigned int *)t25) = 1;
    *((unsigned int *)t38) = 1;
    goto LAB109;

LAB110:    *((unsigned int *)t32) = 1;
    goto LAB113;

LAB112:    *((unsigned int *)t32) = 1;
    *((unsigned int *)t64) = 1;
    goto LAB113;

LAB114:    t68 = *((unsigned int *)t88);
    t69 = *((unsigned int *)t73);
    *((unsigned int *)t88) = (t68 | t69);
    t74 = (t13 + 4U);
    t75 = (t32 + 4U);
    t78 = *((unsigned int *)t13);
    t79 = (~(t78));
    t81 = *((unsigned int *)t74);
    t82 = (~(t81));
    t83 = *((unsigned int *)t32);
    t84 = (~(t83));
    t85 = *((unsigned int *)t75);
    t89 = (~(t85));
    t56 = (t79 & t82);
    t57 = (t84 & t89);
    t90 = (~(t56));
    t91 = (~(t57));
    t92 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t92 & t90);
    t93 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t93 & t91);
    t94 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t94 & t90);
    t95 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t95 & t91);
    goto LAB116;

LAB117:    xsi_set_current_line(303, ng0);

LAB120:    xsi_set_current_line(304, ng0);
    t80 = ((char*)((ng8)));
    t86 = (t0 + 4060);
    xsi_vlogvar_assign_value(t86, t80, 0, 0, 3);
    goto LAB119;

LAB122:    xsi_set_current_line(309, ng0);

LAB125:    xsi_set_current_line(310, ng0);
    t5 = ((char*)((ng3)));
    t6 = (t0 + 4060);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 3);
    xsi_set_current_line(311, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4980);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB124;

}

static void A318_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;

LAB0:    t1 = (t0 + 5932U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(318, ng0);
    t2 = (t0 + 6392);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(318, ng0);

LAB5:    xsi_set_current_line(319, ng0);
    t3 = (t0 + 1876U);
    t4 = *((char **)t3);
    t3 = (t4 + 4U);
    t5 = *((unsigned int *)t3);
    t6 = (~(t5));
    t7 = *((unsigned int *)t4);
    t8 = (t7 & t6);
    t9 = (t8 != 0);
    if (t9 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(330, ng0);

LAB10:    xsi_set_current_line(333, ng0);
    t2 = (t0 + 4796);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t10 = (t0 + 4704);
    xsi_vlogvar_generic_wait_assign_value(t10, t4, 2, 0, 0, 3, 0LL);
    xsi_set_current_line(334, ng0);
    t2 = (t0 + 4060);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t10 = (t0 + 3968);
    xsi_vlogvar_generic_wait_assign_value(t10, t4, 2, 0, 0, 3, 0LL);
    xsi_set_current_line(335, ng0);
    t2 = (t0 + 4612);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t10 = (t0 + 4520);
    xsi_vlogvar_generic_wait_assign_value(t10, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(336, ng0);
    t2 = (t0 + 4428);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t10 = (t0 + 4336);
    xsi_vlogvar_generic_wait_assign_value(t10, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(337, ng0);
    t2 = (t0 + 4244);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t10 = (t0 + 4152);
    xsi_vlogvar_generic_wait_assign_value(t10, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(338, ng0);
    t2 = (t0 + 2844U);
    t3 = *((char **)t2);
    t2 = (t0 + 3600);
    xsi_vlogvar_generic_wait_assign_value(t2, t3, 2, 0, 0, 8, 0LL);
    xsi_set_current_line(339, ng0);
    t2 = (t0 + 2756U);
    t3 = *((char **)t2);
    t2 = (t0 + 3508);
    xsi_vlogvar_generic_wait_assign_value(t2, t3, 2, 0, 0, 64, 0LL);
    xsi_set_current_line(340, ng0);
    t2 = (t0 + 3876);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t10 = (t0 + 3784);
    xsi_vlogvar_generic_wait_assign_value(t10, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(341, ng0);
    t2 = (t0 + 4980);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t10 = (t0 + 4888);
    xsi_vlogvar_generic_wait_assign_value(t10, t4, 2, 0, 0, 1, 0LL);

LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(319, ng0);

LAB9:    xsi_set_current_line(321, ng0);
    t10 = ((char*)((ng1)));
    t11 = (t0 + 4704);
    xsi_vlogvar_generic_wait_assign_value(t11, t10, 1, 0, 0, 3, 0LL);
    xsi_set_current_line(322, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3968);
    xsi_vlogvar_generic_wait_assign_value(t3, t2, 2, 0, 0, 3, 0LL);
    xsi_set_current_line(323, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4520);
    xsi_vlogvar_generic_wait_assign_value(t3, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(324, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4336);
    xsi_vlogvar_generic_wait_assign_value(t3, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(325, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4152);
    xsi_vlogvar_generic_wait_assign_value(t3, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(326, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3600);
    xsi_vlogvar_generic_wait_assign_value(t3, t2, 1, 0, 0, 8, 0LL);
    xsi_set_current_line(327, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 3508);
    xsi_vlogvar_generic_wait_assign_value(t3, t2, 1, 0, 0, 64, 0LL);
    xsi_set_current_line(328, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4888);
    xsi_vlogvar_generic_wait_assign_value(t3, t2, 1, 0, 0, 1, 0LL);
    goto LAB8;

}

static void implSig1_execute(char *t0)
{
    char t3[24];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 6060U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1172U);
    t4 = *((char **)t2);
    t2 = (t0 + 1260U);
    t5 = *((char **)t2);
    xsi_vlogtype_concat(t3, 72, 72, 2U, t5, 8, t4, 64);
    t2 = (t0 + 6524);
    t6 = (t2 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    xsi_vlog_bit_copy(t9, 0, t3, 0, 72);
    xsi_driver_vfirst_trans(t2, 0, 71);
    t10 = (t0 + 6400);
    *((int *)t10) = 1;

LAB1:    return;
}

static void implSig2_execute(char *t0)
{
    char t3[24];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    t1 = (t0 + 6188U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3508);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 3600);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    xsi_vlogtype_concat(t3, 72, 72, 2U, t8, 8, t5, 64);
    t9 = (t0 + 6560);
    t10 = (t9 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    xsi_vlog_bit_copy(t13, 0, t3, 0, 72);
    xsi_driver_vfirst_trans(t9, 0, 71);
    t14 = (t0 + 6408);
    *((int *)t14) = 1;

LAB1:    return;
}


extern void work_m_00000000003013529447_0948142031_init()
{
	static char *pe[] = {(void *)C122_0,(void *)C123_1,(void *)A234_2,(void *)A318_3,(void *)implSig1_execute,(void *)implSig2_execute};
	xsi_register_didat("work_m_00000000003013529447_0948142031", "isim/_tmp/work/m_00000000003013529447_0948142031.didat");
	xsi_register_executes(pe);
}
